---
title: "PhishGuard-XAI: An Explainable and Drift-Aware Framework for Phishing URL Detection"
author: "Nandhini P.^1^ — ^1^Department of Computer Science and Business Systems, KGiSL Institute of Technology, Coimbatore, India"
---

**Target venue (suggested, verify current quartile on SCImago/JCR before submitting):** Computers & Security; Expert Systems with Applications; Journal of Information Security and Applications.

# Abstract

Phishing websites keep changing their appearance, so classifiers trained once tend to lose accuracy over time, and security analysts rarely trust detectors that cannot justify a verdict. This paper presents PhishGuard-XAI, a lightweight framework that combines (i) lexical URL features that need no page download, (ii) a gradient-boosted decision tree classifier, (iii) SHAP-based per-URL explanations, and (iv) a drift monitor based on the Population Stability Index and the Kolmogorov–Smirnov test that triggers weighted retraining. We evaluate the framework on [DATASET NAME, N URLs] using a chronological split. The best model reaches an F1-score of [X.XXX] and an AUC of [X.XXX]; under distribution shift, a static model drops to [X.XXX] F1 while drift-triggered retraining recovers [X.XXX]. [ONE SENTENCE ON MAIN INSIGHT FROM SHAP]. Code is publicly available at [GITHUB/ZENODO DOI].

**Keywords:** phishing detection; explainable AI; SHAP; concept drift; URL analysis; gradient boosting

# 1. Introduction

Phishing remains one of the most common routes for credential theft and fraud. [CITE: recent report, e.g., APWG quarterly trends — add verified figure and citation.] Blocklists react only after a site has been reported, which leaves a window in which victims are exposed. Machine-learning detectors close part of this gap by classifying URLs or page content directly.

Three practical problems limit the deployment of such detectors:

1. **Drift.** Attackers adapt their URL patterns, certificates and hosting habits. A model fitted on last year's data meets a different distribution at test time.
2. **Opacity.** High-accuracy ensembles are hard to audit. Analysts and regulators increasingly require a reason for each block decision.
3. **Cost.** Detectors that fetch and render pages are slow and can themselves expose the defender to malicious content.

This work addresses the three problems together in a single, reproducible pipeline. The contributions are:

- A URL-only detector built on 18 inexpensive lexical features, so that decisions are made before any connection to the suspect host.
- A per-decision explanation layer that reports the features pushing a URL towards or away from the phishing class.
- A drift monitor that compares live feature distributions with the training reference and triggers recency-weighted retraining when an alarm is raised.
- A chronological evaluation protocol and open-source implementation that make the drift results reproducible.

The remainder of the paper is organised as follows. Section 2 reviews existing systems, Section 3 describes the proposed system, Section 4 presents the architecture, Section 5 the experimental setup, Section 6 the implementation, Section 7 the results, and Section 8 concludes with future work.

# 2. Existing Systems and Related Work

**2.1 Blocklist and reputation systems.** Browser-integrated blocklists are fast and precise for known threats but cannot generalise to newly registered domains. [CITE 2–3 verified papers/reports on blocklist latency.]

**2.2 Content- and visual-similarity approaches.** These methods analyse HTML, JavaScript or page screenshots and compare them against brand templates. They can be accurate but require fetching the page, are slower, and are vulnerable to cloaking. [CITE.]

**2.3 URL-based machine learning.** Lexical and host-based features have been combined with random forests, support vector machines, gradient boosting and deep networks. [CITE a representative set from the last five years; include the dataset papers you use.]

**2.4 Deep and transformer models.** Character-level CNNs, recurrent networks and transformer encoders learn representations directly from the URL string and often report very high accuracy on random splits. [CITE.] Their reported scores are frequently measured on random rather than chronological splits, which overstates real-world performance.

**2.5 Explainability in security analytics.** SHAP (Lundberg & Lee, 2017) attributes a prediction to input features using Shapley values and has efficient exact algorithms for tree ensembles. [CITE security-specific XAI papers.]

**2.6 Drift handling.** Population Stability Index, two-sample tests and error-rate detectors are standard drift tools in applied machine learning. [CITE concept-drift survey and any phishing-specific drift study.]

**Table 1. Comparison with existing systems** *(complete from your literature survey; 8–12 rows recommended)*

| Work | Input | Model | Explainable | Drift handled | Chronological eval |
|---|---|---|---|---|---|
| [Ref] | | | | | |
| [Ref] | | | | | |
| **PhishGuard-XAI** | URL only | XGBoost | Yes (SHAP) | Yes (PSI/KS) | Yes |

**Research gap.** Few studies jointly address explanation and temporal drift on a URL-only detector under a chronological protocol. *(Check that this claim holds against your final survey; soften it if you find a counter-example.)*

# 3. Proposed System

PhishGuard-XAI takes a raw URL and returns a phishing probability, a label, and the five features that contributed most to the decision. It consists of four modules.

**3.1 Feature extraction.** Eighteen features are computed from the URL string alone: total, host and path lengths; counts of dots, hyphens, digits and special characters; digit ratio; number of subdomains; presence of an IP-address host, an "@" symbol, HTTPS, and a known shortener; number of query parameters; count of security-themed keywords (e.g., login, verify, secure); Shannon entropy of the host and path; and top-level-domain length.

**3.2 Classifier.** A gradient-boosted tree ensemble (XGBoost) is the primary model. Logistic regression, random forest and a multilayer perceptron serve as baselines.

**3.3 Explanation module.** For every prediction, TreeSHAP values are computed and the top-k features by absolute contribution are reported with their sign.

**3.4 Drift monitor and adaptation.** For each feature, PSI and the KS statistic compare a reference window (training data) with the current window. A drift alarm is raised when more than 25% of features exceed PSI > 0.2 or a KS p-value < 0.01. On alarm, the model is retrained on the union of the original data and a labelled recent window, with recent samples given a weight of 3.

*(Report a sensitivity analysis for the 25% / 0.2 / 3.0 settings in Section 7 so reviewers see that they were not tuned on the test set.)*

# 4. System Architecture

![Figure 1. Architecture of PhishGuard-XAI.](../outputs/fig_architecture.png){width=6.5in}

Incoming URLs pass through the feature extractor. The resulting feature vectors are sent in parallel to the classifier, which produces the verdict, and to the drift monitor, which accumulates a sliding window. The explainer attaches reasons to each verdict. When the drift monitor raises an alarm, labelled samples from the recent window (obtained from analyst feedback or threat-intelligence feeds) are used to retrain the classifier, and the reference window is reset.

# 5. Experimental Setup

**5.1 Datasets.** [NAME, source, number of phishing/legitimate URLs, collection period, licence, download date.] Use at least two datasets or one large dataset with timestamps. Remove duplicate URLs and any URL that appears in more than one split.

**5.2 Splitting protocol.** Data are split chronologically: the earliest [X]% for training, the next [Y]% for validation, and the most recent [Z]% as the drift test set. A random 80/20 split is also reported for comparability with prior work, and clearly labelled as optimistic.

**5.3 Baselines.** Logistic regression, random forest, MLP and [add one deep/transformer baseline to satisfy reviewers].

**5.4 Metrics.** Accuracy, precision, recall, F1, ROC-AUC, five-fold cross-validated F1 (mean ± s.d.), training time, and inference latency per URL. Statistical significance is assessed with [McNemar's test / paired bootstrap over [N] runs].

**5.5 Hyper-parameters.** XGBoost: 250 trees, depth 6, learning rate 0.1. Random forest: 200 trees. MLP: two hidden layers (64, 32). *(State how these were chosen, e.g., grid search on the validation split only.)*

**5.6 Environment.** [CPU/GPU, RAM, OS]; Python [version]; scikit-learn [version]; XGBoost [version]; SHAP [version]; random seed 42.

# 6. Implementation

The system is implemented in Python. `features.py` parses URLs with the standard library; `drift.py` implements PSI and the KS test (SciPy); `models.py` defines the classifiers; `explain.py` wraps the SHAP TreeExplainer; and `run_experiments.py` executes training, evaluation, explanation, drift detection and adaptation end to end and writes every table and figure used in this paper. A command-line tool (`src/app.py`) returns a verdict and reasons for a single URL. The full source and instructions are available at [GITHUB URL] (archived at [ZENODO DOI]).

![Figure 2. Example per-URL output of the inference tool *(replace with screenshot from your real run)*.](../outputs/fig_shap_summary.png){width=4.5in}

# 7. Results and Discussion

> **All numbers below must come from your real-data run. Do not publish values from the `--demo` mode.**

**7.1 Model comparison.** Table 2 lists the metrics of all models on the chronological test set. [DESCRIBE which model wins and by how much, with confidence intervals.]

**Table 2. Model comparison** *(from `outputs/table_model_comparison.csv`)*

| Model | Acc. | Prec. | Rec. | F1 | AUC | CV-F1 (mean ± sd) | Train (s) |
|---|---|---|---|---|---|---|---|
| LogReg | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| RandomForest | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| MLP | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| XGBoost | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

![Figure 3. ROC curves *(replace with real run)*.](../outputs/fig_roc.png){width=3.6in}

**7.2 Explainability analysis.** Figure 4 shows the SHAP summary. [DESCRIBE the top features, their direction, and whether they match domain knowledge. Discuss at least one misclassified URL with its explanation.]

**7.3 Drift analysis.** The drift monitor flagged [N] of 18 features, led by [FEATURES] (Figure 5). [REPORT time-to-detection if you simulate a stream.]

![Figure 5. Feature-level PSI between training and later data *(replace with real run)*.](../outputs/fig_drift_psi.png){width=3.8in}

**7.4 Adaptation.** Table 3 compares the static model with drift-triggered retraining on held-out later data.

**Table 3. Effect of adaptation** *(from `outputs/table_adaptation.csv`)*

| Stage | F1 | Recall | AUC |
|---|---|---|---|
| Static model | [ ] | [ ] | [ ] |
| Drift-triggered retraining | [ ] | [ ] | [ ] |

**7.5 Ablation and sensitivity.** [Remove each feature group; vary the PSI threshold, alarm fraction and recency weight.]

**7.6 Limitations.** Lexical features can be evaded by attackers who mimic benign URL structure; the study depends on dataset label quality; adaptation needs fresh labels; and explanations describe the model's behaviour, not causal attacker intent. [ADD dataset-specific limitations.]

# 8. Conclusion and Future Work

This paper introduced PhishGuard-XAI, a URL-only phishing detector that explains its decisions and adapts when the data distribution shifts. [SUMMARISE real quantitative findings.]

Future work includes: (i) combining lexical features with certificate, WHOIS and passive-DNS signals; (ii) comparing against character-level and transformer models under the same chronological protocol; (iii) label-efficient adaptation using active learning or semi-supervised updates, so that retraining does not depend on full manual labelling; (iv) adversarial robustness testing against URL-mimicry attacks; (v) browser-extension deployment with a user study on explanation usefulness; and (vi) federated training across organisations without sharing raw URLs.

# Declarations

**Author contributions:** [CRediT roles]. **Funding:** [ ]. **Conflict of interest:** [ ]. **Data availability:** [dataset source/links]. **Code availability:** [GitHub + Zenodo DOI]. **Use of AI tools:** [Disclose assistance with drafting/code according to the target journal's policy.]

# References

*Verified core references (check formatting against the journal's style):*

1. Chen, T., & Guestrin, C. (2016). XGBoost: A scalable tree boosting system. *Proceedings of the 22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining*, 785–794.
2. Lundberg, S. M., & Lee, S.-I. (2017). A unified approach to interpreting model predictions. *Advances in Neural Information Processing Systems 30*.
3. Breiman, L. (2001). Random forests. *Machine Learning, 45*(1), 5–32.

*Add 30–50 additional references from your own literature search (Scopus/Web of Science/Google Scholar), all read and verified by you. Do not copy citations you have not opened.*
