"""Tiny CLI/inference demo: score a URL and show the top contributing features (SHAP).
Run after run_experiments.py has produced a model:  python -m src.app http://example-login.xyz/verify
"""
import sys, pickle, numpy as np, pandas as pd, shap
from .features import extract
from .data import make_synthetic
from xgboost import XGBClassifier

def main(url):
    X, y, _ = make_synthetic(8000, seed=1)       # replace with your real training set
    m = XGBClassifier(n_estimators=250, max_depth=6, eval_metric="logloss").fit(X, y)
    x = pd.DataFrame([extract(url)])
    p = m.predict_proba(x)[0, 1]
    sv = shap.TreeExplainer(m).shap_values(x)[0]
    top = sorted(zip(x.columns, sv), key=lambda t: -abs(t[1]))[:5]
    print(f"URL: {url}\nPhishing probability: {p:.3f} -> {'PHISHING' if p>.5 else 'LEGITIMATE'}\nTop reasons:")
    for f, v in top: print(f"  {f:15s} {'+' if v>0 else '-'}{abs(v):.3f}")

if __name__ == "__main__":
    main(sys.argv[1])
