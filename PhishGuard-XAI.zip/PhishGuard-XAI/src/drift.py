"""Concept/data drift detection: Population Stability Index + KS test per feature."""
import numpy as np, pandas as pd
from scipy.stats import ks_2samp

def psi(ref, cur, bins=10, eps=1e-6):
    qs = np.unique(np.quantile(ref, np.linspace(0, 1, bins + 1)))
    if len(qs) < 3:
        return 0.0
    r = np.histogram(ref, qs)[0] / len(ref) + eps
    c = np.histogram(np.clip(cur, qs[0], qs[-1]), qs)[0] / len(cur) + eps
    return float(np.sum((c - r) * np.log(c / r)))

def drift_report(Xref: pd.DataFrame, Xcur: pd.DataFrame, psi_thr=0.2, alpha=0.01):
    rows = []
    for col in Xref.columns:
        p = psi(Xref[col].to_numpy(), Xcur[col].to_numpy())
        ks = ks_2samp(Xref[col], Xcur[col])
        rows.append({"feature": col, "psi": p, "ks_stat": ks.statistic,
                     "ks_p": ks.pvalue, "drifted": p > psi_thr or ks.pvalue < alpha})
    rep = pd.DataFrame(rows).sort_values("psi", ascending=False)
    return rep, bool(rep["drifted"].mean() > 0.25)   # alarm if >25% features drift
