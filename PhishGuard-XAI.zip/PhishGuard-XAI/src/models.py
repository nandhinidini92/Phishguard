from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

def get_models(seed=42):
    return {
        "LogReg": make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000)),
        "RandomForest": RandomForestClassifier(n_estimators=200, random_state=seed, n_jobs=-1),
        "MLP": make_pipeline(StandardScaler(), MLPClassifier((64, 32), max_iter=300, random_state=seed)),
        "XGBoost": XGBClassifier(n_estimators=250, max_depth=6, learning_rate=0.1,
                                 eval_metric="logloss", random_state=seed),
    }
