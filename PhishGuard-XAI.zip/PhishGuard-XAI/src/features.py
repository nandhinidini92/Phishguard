"""Lexical / host-based URL feature extraction (no network access required)."""
import re, math
from urllib.parse import urlparse
from collections import Counter

SUSPICIOUS_WORDS = ["login", "verify", "secure", "account", "update", "bank",
                    "confirm", "password", "signin", "wallet", "free", "bonus"]
SHORTENERS = ("bit.ly", "tinyurl.com", "goo.gl", "t.co", "ow.ly", "is.gd")

def _entropy(s: str) -> float:
    if not s:
        return 0.0
    c = Counter(s)
    n = len(s)
    return -sum(v / n * math.log2(v / n) for v in c.values())

def extract(url: str) -> dict:
    u = url if "://" in url else "http://" + url
    p = urlparse(u)
    host, path, query = p.netloc.lower(), p.path, p.query
    parts = host.split(".")
    return {
        "url_len": len(url),
        "host_len": len(host),
        "path_len": len(path),
        "n_dots": url.count("."),
        "n_hyphens": host.count("-"),
        "n_digits": sum(ch.isdigit() for ch in url),
        "digit_ratio": sum(ch.isdigit() for ch in url) / max(len(url), 1),
        "n_subdomains": max(len(parts) - 2, 0),
        "has_ip": int(bool(re.fullmatch(r"(\d{1,3}\.){3}\d{1,3}(:\d+)?", host))),
        "has_at": int("@" in url),
        "is_https": int(p.scheme == "https"),
        "n_params": len(query.split("&")) if query else 0,
        "n_susp_words": sum(w in url.lower() for w in SUSPICIOUS_WORDS),
        "is_shortener": int(any(host.endswith(s) for s in SHORTENERS)),
        "host_entropy": _entropy(host),
        "path_entropy": _entropy(path),
        "n_special": sum(not ch.isalnum() for ch in url),
        "tld_len": len(parts[-1]) if parts else 0,
    }
