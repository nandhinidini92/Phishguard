"""Dataset utilities.

Two modes:
  1. load_csv(path)  -> real data (columns: url,label  with label 1=phishing, 0=legitimate)
  2. make_synthetic(...) -> generator for smoke-testing the pipeline ONLY.
     Results on synthetic data must NOT be reported in a paper.
"""
import random, string
import numpy as np, pandas as pd
from .features import extract

def load_csv(path, url_col="url", label_col="label"):
    df = pd.read_csv(path)
    X = pd.DataFrame([extract(u) for u in df[url_col].astype(str)])
    return X, df[label_col].astype(int).to_numpy()

def _rand(n, chars=string.ascii_lowercase):
    return "".join(random.choice(chars) for _ in range(n))

def _legit(rng_shift=0.0):
    tld = random.choice(["com", "org", "edu", "net", "in", "io"])
    path = "/".join(_rand(random.randint(3, 8), string.ascii_lowercase + (string.digits if random.random() < .3 else ""))
                    for _ in range(random.randint(0, 4)))
    q = f"?id={random.randint(1,9999)}&ref={_rand(5)}" if random.random() < .25 else ""
    host = f"{'www.' if random.random()<.7 else ''}{_rand(random.randint(4, 12))}{'-'+_rand(4) if random.random()<.15 else ''}.{tld}"
    scheme = "https" if random.random() < .9 else "http"
    if random.random() < .08:   # hard negatives: legit pages that look suspicious
        path = random.choice(["login", "account/update", "secure/signin"]) + "/" + path
    return f"{scheme}://{host}/{path}{q}"

def _phish(rng_shift=0.0):
    word = random.choice(["login", "verify", "secure", "account", "update", "bank", "confirm"])
    r = random.random()
    # evolved, stealthy attacks (HTTPS, short, clean-looking) grow under drift
    if r < 0.12 + rng_shift:
        return f"https://www.{_rand(random.randint(5, 10))}.{random.choice(['com','net','org'])}/{_rand(random.randint(3,8))}/{_rand(5)}"
    if r < 0.27 + rng_shift:
        return f"http://{random.randint(11,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}/{word}/{_rand(6)}.php"
    scheme = "https" if random.random() < .35 else "http"
    return (f"{scheme}://{word}-{_rand(random.randint(4,8))}.{_rand(6)}."
            f"{random.choice(['com','info','top','xyz','net'])}/{word}/{_rand(random.randint(5,12), string.ascii_lowercase+string.digits)}")

def make_synthetic(n=6000, phish_ratio=0.5, drift=0.0, seed=0):
    random.seed(seed); np.random.seed(seed)
    urls, y = [], []
    for _ in range(n):
        if random.random() < phish_ratio:
            urls.append(_phish(drift)); y.append(1)
        else:
            urls.append(_legit(drift)); y.append(0)
    X = pd.DataFrame([extract(u) for u in urls])
    return X, np.array(y), urls
