import numpy as np, shap, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def shap_summary(model, X_background, X_explain, out_png):
    expl = shap.TreeExplainer(model)
    sv = expl.shap_values(X_explain)
    plt.figure()
    shap.summary_plot(sv, X_explain, show=False)
    plt.tight_layout(); plt.savefig(out_png, dpi=160); plt.close()
    return np.abs(sv).mean(0)
